package ca.uwaterloo.gsd.rangeFix
import collection._

object Expression {
	implicit def string2VarRef(s:String) = IdentifierRef(s)
	implicit def int2literal(s:Int) = IntLiteral(s)
	implicit def bool2literal(s:Boolean) = BoolLiteral(s)
	
	type Types = collection.Map[String, SingleType]
	type Configuration = collection.Map[String, Literal]
	
}

sealed abstract class Expression extends Serializable{
  def children():List[Expression] =  
	(for(i <- 0 until this.asInstanceOf[Product].productArity;
		child = this.asInstanceOf[Product].productElement (i);
		if (child.isInstanceOf[Expression])) 
		yield child.asInstanceOf[Expression]).toList
		
	def < (r:Expression) = LessThan(this, r)
	def > (r:Expression) = GreaterThan(this, r)
	def + (r:Expression) = Plus(this, r)
	def - (r:Expression) = Minus(this, r)
	def & (r:Expression) = And(this, r)
	def | (r:Expression) = Or(this, r)
	def ==> (r:Expression) = Implies(this, r)
	def <= (r:Expression) = LessThanOrEq(this, r)
	def >= (r:Expression) = GreaterThanOrEq(this, r)
	def === (r:Expression) = Eq(this, r)
	def unary_! : Expression = Not(this)

}

abstract class Literal extends Expression
abstract class EnumItemLiteral extends Literal

case class StringLiteral(value : String) extends EnumItemLiteral {
  override def toString = "\"" + value + "\""
}
case class IntLiteral(value : Long) extends EnumItemLiteral {
  override def toString = value.toString
}
case class BoolLiteral(value : Boolean) extends Literal {
	override def toString = if (value) "true" else "false"
}
case class RealLiteral(value : Double) extends EnumItemLiteral {
  override def toString = value.toString
}
case class SetLiteral(values : Set[String]) extends Literal {
	override def toString = values.toString
}

case class EnumLiteral(value : EnumItemLiteral, t:EnumType) extends Literal {
	assert (t.items.contains(value))
	override def toString = t.toString + "." + value
}

case class IdentifierRef(id : String) extends Expression {
  override def toString = id
}

case class Conditional(cond : Expression,
                       pass : Expression,
                       fail : Expression) extends Expression {
	override def toString = "( if " + cond + " then " + pass + " else " + fail + " )"
}					   

sealed abstract class UnaryExpression(e : Expression,
                                      op : String) extends Expression {
  override def toString = op + e
}

sealed abstract class BinaryExpression(l : Expression,
                                       r : Expression,
                                       op : String) extends Expression {
  override def toString = "(" + l + " "  + op + " " + r + ")"
}

case class Or(left : Expression, right : Expression)
        extends BinaryExpression(left, right, "||")
case class And(left : Expression, right : Expression)
        extends BinaryExpression(left, right, "&&")
case class Implies(left : Expression, right : Expression)
        extends BinaryExpression(left, right, "implies")

case class Eq(left : Expression, right : Expression)
        extends BinaryExpression(left, right, "==")
case class NEq(left : Expression, right : Expression)
        extends BinaryExpression(left, right, "!=")

case class LessThan(left : Expression, right : Expression)
        extends BinaryExpression(left, right, "<")
case class LessThanOrEq(left : Expression, right : Expression)
        extends BinaryExpression(left, right, "<=")
case class GreaterThan(left : Expression, right : Expression)
        extends BinaryExpression(left, right, ">")
case class GreaterThanOrEq(left : Expression, right : Expression)
        extends BinaryExpression(left, right, ">=")
		
case class Plus(left :Expression, right : Expression)
        extends BinaryExpression(left, right, "+")
case class Minus(left :Expression, right : Expression)
        extends BinaryExpression(left, right, "-")

case class Times(left :Expression, right : Expression)
        extends BinaryExpression(left, right, "*")
case class Div(left :Expression, right : Expression)
        extends BinaryExpression(left, right, "/")
case class Mod(left :Expression, right : Expression)
        extends BinaryExpression(left, right, "%")

case class Dot(left : Expression, right : Expression)
        extends BinaryExpression(left, right, ".")
		
case class Not(expr : Expression)
        extends UnaryExpression(expr, "!")

abstract class FunctionCall(name : String, arguments : String*) extends Expression{
  override def toString() = name + "(" + arguments.foldLeft("")( (a,b) => a + ( if( a!="" ) "," else "" ) + b ) + ")"
}

case class IsSubstr(container:Expression, containee:Expression) extends FunctionCall("is_substr", container.toString, containee.toString)
case class ToInt(n:Expression) extends FunctionCall("toInt", n.toString)
case class ToString(n:Expression) extends FunctionCall("toString", n.toString)
case class ToBool(n:Expression) extends FunctionCall("toBool", n.toString)

object ExpressionHelper {
	private def toInt(l:Literal):Long = l match {
		case StringLiteral(s) =>
			try {
				s.toInt
			}
			catch {
				case _:java.lang.NumberFormatException => 0
			}
		case IntLiteral(i) => i
		case BoolLiteral(b) => if (b) 1 else 0
		case EnumLiteral(v, t) => toInt(v)
		case SetLiteral(_) => toInt(StringLiteral(toString(l)))
	}
	private def toString(l:Literal):String = l match {
		case StringLiteral(s) => s
		case IntLiteral(i) => i.toString
		case b:BoolLiteral => toInt(b).toString
		case EnumLiteral(v, t) => toString(v)
		case SetLiteral(vs) => if (vs.size > 0) vs.reduce(_ + " " + _) else ""
	}
	private def toBoolean(l:Literal):Boolean = {
		l match {
			case StringLiteral(s) if s == "0" || s == "" => false
			case StringLiteral(s) => true
			case EnumLiteral(v, t) => toBoolean(v)
			case _ => toInt(l) != 0
		}
	}
	
	def evaluateUntypedExpr(exp:Expression, valuation:Map[String, EnumItemLiteral]=Map[String, EnumItemLiteral]()):EnumItemLiteral = {
		def evaluateAsGeneralExpr(exp:Expression):EnumItemLiteral = ExpressionHelper.evaluateUntypedExpr(exp, valuation)
		def toLiteral(b:Boolean):EnumItemLiteral = if (b) IntLiteral(1) else IntLiteral(0)
		exp match {
			case l:EnumItemLiteral => l
			case i:IdentifierRef => valuation.getOrElse(i.id, IntLiteral(0))
			case Conditional(c, p, f) => if (toBoolean(evaluateAsGeneralExpr(c))) evaluateAsGeneralExpr(p) else evaluateAsGeneralExpr(f)
			case Or(l, r) => 
				if (toBoolean(evaluateAsGeneralExpr(l))) IntLiteral(1) 
				else if (toBoolean(evaluateAsGeneralExpr(r))) IntLiteral(1)
				else IntLiteral(0)
			case And(l, r) => 
				if (!toBoolean(evaluateAsGeneralExpr(l))) IntLiteral(0) 
				else if (toBoolean(evaluateAsGeneralExpr(r))) IntLiteral(1)
				else IntLiteral(0)
			case Implies(l, r) => evaluateAsGeneralExpr(Or(Not(l), r))
			case Eq(l, r) => 
				if (toString(evaluateAsGeneralExpr(l)) == toString(evaluateAsGeneralExpr(r))) IntLiteral(1)
				else IntLiteral(0)
			case NEq(l, r) => evaluateAsGeneralExpr(Not(Eq(l, r)))
			case LessThan(l, r) => toLiteral(toInt(evaluateAsGeneralExpr(l)) < toInt(evaluateAsGeneralExpr(r)))
			case LessThanOrEq(l, r) => 
				toLiteral(toInt(evaluateAsGeneralExpr(l)) <= toInt(evaluateAsGeneralExpr(r)))
			case GreaterThanOrEq(l, r) => 
				toLiteral(toInt(evaluateAsGeneralExpr(l)) >= toInt(evaluateAsGeneralExpr(r)))
			case GreaterThan(l, r) => toLiteral(toInt(evaluateAsGeneralExpr(l)) > toInt(evaluateAsGeneralExpr(r)))
			case Plus(l, r) => IntLiteral(toInt(evaluateAsGeneralExpr(l)) + toInt(evaluateAsGeneralExpr(r)))
			case Minus(l, r) => IntLiteral(toInt(evaluateAsGeneralExpr(l)) - toInt(evaluateAsGeneralExpr(r)))
			case Times(l, r) => IntLiteral(toInt(evaluateAsGeneralExpr(l)) * toInt(evaluateAsGeneralExpr(r)))
			case Div(l, r) => IntLiteral(toInt(evaluateAsGeneralExpr(l)) / toInt(evaluateAsGeneralExpr(r)))
			case Mod(l, r) => IntLiteral(toInt(evaluateAsGeneralExpr(l)) % toInt(evaluateAsGeneralExpr(r)))
			case Dot(l, r) => StringLiteral(toString(evaluateAsGeneralExpr(l)) + toString(evaluateAsGeneralExpr(r)))
			case Not(l) => toLiteral(!toBoolean(evaluateAsGeneralExpr(l)))
			case IsSubstr(l, r) => toLiteral(toString(evaluateAsGeneralExpr(l)).contains(toString(evaluateAsGeneralExpr(r))))
			case ToInt(l) => IntLiteral(toInt(evaluateAsGeneralExpr(l)))
			case ToString(l) => StringLiteral(toString(evaluateAsGeneralExpr(l)))
			case ToBool(l) => toLiteral(toBoolean(evaluateAsGeneralExpr(l)))
			case _ => throw new IllegalArgumentException("The experssion contains " + exp)
		}
	}

	def evaluateTypeCorrectExpression(e:Expression, valuation:String=>Literal = Map(), debug: Boolean = false):Literal = {
		def evaluate(e:Expression): Literal = {
			if (debug)  println("Current: " + e)
			def isBoolTrue(l:Literal) =
				if (l == BoolLiteral(true)) true
				else {
					assert(l == BoolLiteral(false), l)
					false
				}
			def asInt(l:Literal) = {
				assert(l.isInstanceOf[IntLiteral], l)
				l.asInstanceOf[IntLiteral].value
			}
			def asString(l:Literal) = {
				assert(l.isInstanceOf[StringLiteral])
				l.asInstanceOf[StringLiteral].value
			}
			def asSet(l:Literal) = {
				assert(l.isInstanceOf[SetLiteral])
				l.asInstanceOf[SetLiteral].values
			}
			def getLiteralType(l:Literal) = l match {
				case _:IntLiteral => NumberType
				case _:RealLiteral => NumberType
				case EnumLiteral(_, t) => t
				case _:StringLiteral => StringType
				case _:BoolLiteral => BoolType
			}
			val result = e match {
				case l:Literal => l
				case i:IdentifierRef => valuation(i.id)
				case Conditional(c, p, f) => 
					if (isBoolTrue(evaluate(c))) evaluate(p) else evaluate(f)
				case Or(l, r) => 
					if (isBoolTrue(evaluate(l))) BoolLiteral(true)
					else if (isBoolTrue(evaluate(r))) BoolLiteral(true)
					else BoolLiteral(false)
				case And(l, r) => 
					if (!isBoolTrue(evaluate(l))) BoolLiteral(false) 
					else if (isBoolTrue(evaluate(r))) BoolLiteral(true)
					else BoolLiteral(false)
				case Implies(l, r) => evaluate(Or(Not(l), r))
				case Eq(l, r) => 
					assert (getLiteralType(evaluate(l)) == getLiteralType(evaluate(r)), Eq(l, r).toString + " where " + l + ":" + getLiteralType(evaluate(l)) + " and " + r + ":" + getLiteralType(evaluate(r)))
					if (evaluate(l) == evaluate(r)) BoolLiteral(true)
					else BoolLiteral(false)
				case NEq(l, r) => evaluate(Not(Eq(l, r)))
				case LessThan(l, r) => BoolLiteral(asInt(evaluate(l)) < asInt(evaluate(r)))
				case LessThanOrEq(l, r) => 
					BoolLiteral(asInt(evaluate(l)) <= asInt(evaluate(r)))
				case GreaterThanOrEq(l, r) => 
					BoolLiteral(asInt(evaluate(l)) >= asInt(evaluate(r)))
				case GreaterThan(l, r) => BoolLiteral(asInt(evaluate(l)) > asInt(evaluate(r)))
				case Plus(l, r) => IntLiteral(asInt(evaluate(l)) + asInt(evaluate(r)))
				case Minus(l, r) => IntLiteral(asInt(evaluate(l)) - asInt(evaluate(r)))
				case Times(l, r) => IntLiteral(asInt(evaluate(l)) * asInt(evaluate(r)))
				case Div(l, r) => IntLiteral(asInt(evaluate(l)) / asInt(evaluate(r)))
				case Mod(l, r) => IntLiteral(asInt(evaluate(l)) % asInt(evaluate(r)))
				case Dot(l, r) => SetLiteral(asSet(evaluate(l)) ++ asSet(evaluate(r))) //StringLiteral(asString(evaluate(l)) + asString(evaluate(r)))
				case Not(l) => BoolLiteral(!isBoolTrue(evaluate(l)))
				case IsSubstr(l, r) => BoolLiteral(asSet(evaluate(r)).subsetOf(asSet(evaluate(l)))) //BoolLiteral(asString(evaluate(l)).contains(asString(evaluate(r))))
				case ToInt(l) => IntLiteral(toInt(evaluate(l)))
				case ToString(l) => StringLiteral(toString(evaluate(l)))
				case ToBool(l) => BoolLiteral(toBoolean(evaluate(l)))
				case _ => throw new IllegalArgumentException("The experssion contains " + e)
			}
			result
		}
		evaluate(e)
	}
	
	private def getStrictLiteralType(l:Literal):Type = l match {
		case _:IntLiteral => NumberType
		case _:StringLiteral => StringType
		case EnumLiteral(v, t) => t
		case _:RealLiteral => NumberType
		case _:BoolLiteral => BoolType
		case _:SetLiteral => SetType
	}
	
	// assuming expr is type correct
	def getType(expr:Expression, types:collection.Map[String, Type], getLiteralType:(Literal)=>Type = getStrictLiteralType):Type = {
		expr match {
			case l:Literal => getLiteralType(l)
			case IdentifierRef(id) => types.getOrElse(id, TypeHelper.anyType)
			case Conditional(c, p, f) => (getType(p, types, getLiteralType) & getType(f, types, getLiteralType)).get
			case Or(l, r) => BoolType
			case And(l, r) => BoolType
			case Implies(l, r) => BoolType
			case Eq(l, r) => BoolType
			case NEq(l, r) => BoolType
			case LessThan(l, r) => BoolType
			case LessThanOrEq(l, r) => BoolType
			case GreaterThanOrEq(l, r) => BoolType
			case GreaterThan(l, r) => BoolType
			case Plus(l, r) => NumberType
			case Minus(l, r) => NumberType
			case Times(l, r) => NumberType
			case Div(l, r) => NumberType
			case Mod(l, r) => NumberType
			case Dot(l, r) => SetType
			case Not(l) => BoolType
			case IsSubstr(l, r) => BoolType
			case ToInt(l) => NumberType
			case ToString(l) => StringType
			case ToBool(l) => BoolType
			case GetData(id) => types.getOrElse(id, TypeHelper.anyType)
			case _:IsActive => BoolType
			case _:IsEnabled => BoolType
			case _:IsLoaded => BoolType
		}
	}

	private def containsIdentifier(expr:Expression) = {
		import org.kiama.rewriting.Rewriter._	
		var result = false
		rewrite(everywhere(query{
			case a:IdentifierRef => 
				result = true
		} )) (expr)
		result
	}
	

	// only apply to type corrected expr
	def removeToBool(expr:Expression, types:Expression.Types):Expression = {
		import org.kiama.rewriting.Rewriter._ 
		rewrite(everywherebu(rule {
			case ToBool(e) => Not(e === TypeHelper.ZeroToType{
				val t = getType(e, types)
				assert(t.isInstanceOf[SingleType], e.toString + ":" + t)
				t.asInstanceOf[SingleType]
			})
		} )) (expr)
	}
	
	
	// only apply to type corrected expr
	def removeConditional(expr:Expression, types:Expression.Types):Expression = { 
		import org.kiama.rewriting.Rewriter._ 
		def removeSingleBooleanConditional(t:Any):Any = {
			t match {
				case c@Conditional(b, p, f) if getType(c, types) == BoolType => (b & p) | (Not(b) & f)
				case _ => t
			}
		}

		def removeSingleDataConditional(t:Any):Any = {
			object ContainsConditional{
				def unapply(expr:Expression):Option[Conditional] = {
					var r:Option[Conditional] = None
					val isConditional:PartialFunction[Any, Conditional] = { case x:Conditional if r == None => {r = Some(x);x} }
					everywheretd(query(isConditional))(t)
					r
				}
			}

			def replaceSingleConditional(src:Conditional, tgt:Expression):PartialFunction[Any, Any] = {
				case e:Conditional if e == src => tgt
			}

			def replaceConditional(src:Conditional, tgt:Expression)(e:Expression):Expression = 
				rewrite(everywheretd(rule(replaceSingleConditional(src, tgt))))(e)

			t match {
			case e:Expression if getType(e, types) == BoolType && !e.children.exists(getType(_, types) == BoolType) => 
				e match {
					case ContainsConditional(c@Conditional(b, p, f)) => 
						(b & replaceConditional(c, p)(e)) | 
						(Not(b) & replaceConditional(c, f)(e)) 
					case _ => e
				}
			case _ => t
			}
		}
	
		rewrite(everywheretd(rulef(removeSingleBooleanConditional)) <* everywheretd(rulef(removeSingleDataConditional)))(expr)
	}
	
	def removeBooleanEq(expr:Expression, types:Expression.Types):Expression = {
		import org.kiama.rewriting.Rewriter._ 
		rewrite(everywherebu(rule {
			case Eq(x, y) if getType(x, types) == BoolType && getType(y, types) == BoolType => 
				(x & y) | (Not(x) & Not(y))
		} )) (expr)
	}


	def simplifyWithReplacement(expr:Expression, types:Expression.Types):Expression = {
		simplify(removeToBool(removeBooleanEq(removeConditional(simplify(expr), types), types), types))
	}
	
	import org.kiama.rewriting.Rewriter._ 
	def simplify(expr:Expression):Expression = {
		rewrite(everywherebu(rule{
			case And(_, BoolLiteral(false)) => BoolLiteral(false)
			case And(BoolLiteral(false), _) => BoolLiteral(false)
			case And(BoolLiteral(true), e) => e
			case And(e, BoolLiteral(true)) => e
			case And(e1, e2) if e1 == e2 => e1
			case Or(_, BoolLiteral(true)) => BoolLiteral(true)
			case Or(BoolLiteral(true), _) => BoolLiteral(true)
			case Or(BoolLiteral(false), e) => e
			case Or(e, BoolLiteral(false)) => e
			case Or(e1, e2) if e1 == e2 => e1
			case Conditional(BoolLiteral(true), pass, fail) => pass
			case Conditional(BoolLiteral(false), pass, fail) => fail
			case Eq(i1, BoolLiteral(true)) => i1
			case Eq(i1, BoolLiteral(false)) => Not(i1)
			case Plus(IntLiteral(0), e) => e
			case Plus(e, IntLiteral(0)) => e
			case Conditional(e1, e2, BoolLiteral(false)) if e1 == e2 | e2 == BoolLiteral(true) => e1
			case Conditional(e1, BoolLiteral(false), BoolLiteral(true)) => Not(e1)
			case Conditional(e1, e2, e3) if e2 == e3 => e2
			case GreaterThan(IntLiteral(i1), IntLiteral(i2)) => 
				if (i1 > i2) BoolLiteral(true) 
				else BoolLiteral(false)
			case GreaterThanOrEq(IntLiteral(i1), IntLiteral(i2)) => 
				if (i1 >= i2)  BoolLiteral(true) 
				else  BoolLiteral(false)
			case LessThan(IntLiteral(i1), IntLiteral(i2)) => 
				if (i1 < i2)  BoolLiteral(true) 
				else  BoolLiteral(false)
			case LessThanOrEq(IntLiteral(i1), IntLiteral(i2)) => 
				if (i1 <= i2)  BoolLiteral(true) 
				else  BoolLiteral(false)
			case Eq(i1:Literal, i2:Literal) => 
				if (i1 == i2)  BoolLiteral(true) 
				else  BoolLiteral(false)
			case IsSubstr(SetLiteral(l), SetLiteral(r)) => BoolLiteral(r.subsetOf(l))
 			// case IsSubstr(StringLiteral(whole), StringLiteral(part)) =>
				// if (whole.containsSlice(part))  BoolLiteral(true)
				// else  BoolLiteral(false)
			case Implies(l, r) => simplify(Or(Not(l), r))
			case NEq(l, r) => simplify(Not(Eq(l, r)))
			case Plus(IntLiteral(l), IntLiteral(r)) => IntLiteral(l + r)
			case Minus(IntLiteral(l), IntLiteral(r)) => IntLiteral(l - r)
			case Times(IntLiteral(l), IntLiteral(r)) => IntLiteral(l * r)
			case Div(IntLiteral(l), IntLiteral(r)) => IntLiteral(l / r)
			case Mod(IntLiteral(l), IntLiteral(r)) => IntLiteral(l % r)
			// case Dot(StringLiteral(l), StringLiteral(r)) => StringLiteral(l + r)
			case Dot(SetLiteral(l), SetLiteral(r)) => SetLiteral(l ++ r)
			case Not(BoolLiteral(b)) => BoolLiteral(!b)
			case ToInt(i:Literal) => IntLiteral(toInt(i))
			case ToString(i:Literal) => StringLiteral(toString(i))
			case ToBool(i:Literal) => BoolLiteral(toBoolean(i))
		} ))(expr)
	}
}