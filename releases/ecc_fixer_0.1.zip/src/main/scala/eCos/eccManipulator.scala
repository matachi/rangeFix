package ca.uwaterloo.gsd.rangeFix
import java.io._
import collection._

object SerializedEccManipulator {
	// serialization does not work because of some strange bugs in Scala. Have to do it manually
	def saveConfig(config:Map[String, ConfigValue], o:ObjectOutputStream) {
		o.writeInt(config.size)
		for((k, v) <- config) {
			o.writeObject(k)
			v.save(o)
		}
	}
	
	def loadConfig(i:ObjectInputStream):Map[String, ConfigValue] = {
		val size = i.readInt
		(for(index <- 1 to size) yield {
			val k = i.readObject.asInstanceOf[String]
			val v = ConfigValue.load(i)
			(k, v)
		}).toMap
	}
}

abstract class Strategy {
	def fix(smt:SMTPreTranslation, constraintIndex:Int, satisfiedConstraints:Set[Int]):Iterable[DataFix]
}

object PropagationStrategy extends Strategy {
	def fix(smt:SMTPreTranslation, constraintIndex:Int, satisfiedConstraints:Set[Int]) = {
		smt.fix(constraintIndex, satisfiedConstraints)
	}
}
object IgnoranceStrategy extends Strategy {
	def fix(smt:SMTPreTranslation, constraintIndex:Int, satisfiedConstraints:Set[Int]) = {
		smt.fixWithIgnorance(constraintIndex)
	}
}
object EliminationStrategy extends Strategy {
	def fix(smt:SMTPreTranslation, constraintIndex:Int, satisfiedConstraints:Set[Int]) = {
		smt.fixWithElimination(constraintIndex, satisfiedConstraints)
	}
}

class SerializedEccManipulator(serializedArray:Array[Byte]) extends Serializable{
	def this(ecc:EccManipulator) = this{
		val byteArrayStream = new ByteArrayOutputStream
		val output = new ObjectOutputStream(byteArrayStream)
		try {
			output.writeObject(ecc.file)
			output.writeObject(ecc.globalAnnotationPath)
			SerializedEccManipulator.saveConfig(ecc.config, output)
		}
		finally {
			output.close()
		}
		val result = byteArrayStream.toByteArray
		assert({
			val input = new ObjectInputStream(new ByteArrayInputStream(result))
			val first = ecc.file == input.readObject.asInstanceOf[String]
			val second = ecc.globalAnnotationPath == input.readObject.asInstanceOf[String]
			val third = ecc.config == SerializedEccManipulator.loadConfig(input)
			first && second && third
		})
		result
	}
	
	def get() = {
		val input = new ObjectInputStream(new ByteArrayInputStream(serializedArray))
		try {
			val file = input.readObject.asInstanceOf[String]
			val annotation = input.readObject.asInstanceOf[String]
			val result = new EccManipulator(file, annotation)
			result.config = SerializedEccManipulator.loadConfig(input)
			result
		}
		finally {
			input.close
		}		
	}
}


class EccManipulator(val file:String, val globalAnnotationPath:String = "testfiles/realworld/allModels.annotation") {

	// def saveLoadConfigValue(a:ConfigValue):ConfigValue = {
		// val byteArrayStream = new ByteArrayOutputStream
		// val output = new ObjectOutputStream(byteArrayStream)
		// a.save(output)
		// output.close
		// val input = new ObjectInputStream(new ByteArrayInputStream(byteArrayStream.toByteArray))
		// ConfigValue.load(input)
	// }

	// def save(out:ObjectOutputStream) {
		// out.writeObject(file)
		// out.writeObject(globalAnnotationPath)
		// for((k, v) <- config) {
			// println(v)
			// assert(saveLoadConfigValue(v) == v, v + " != " + saveLoadConfigValue(v))
		// }
		// out.writeObject(Map() ++ config)
	// }

	def getUnsatisfiedConstraints():Set[ConstraintWithSource] = getUnsatisfiedConstraintIndexes.map(getConstraint)
	def getSatisfiedConstraints():Set[ConstraintWithSource] = getSatisfiedConstraintIndexes.map(getConstraint)
	def getUnsatisfiedConstraintIndexes():Set[Int] = {
		if (satisficationNeedsUpdate){
			checkConflictsWithIndex
		}
		unsatisfiedConstraints
	}
	def getSatisfiedConstraintIndexes():Set[Int] = {
		if (satisficationNeedsUpdate) {
			checkConflictsWithIndex
		}
		satisfiedConstraints
	}
	def getConstraint(index:Int):ConstraintWithSource = {
		if (!constraintRange.contains(index)) 
			throw new java.lang.IllegalArgumentException("constraint index out of range")
		allConditions(constraintRange.head + index)
	}
	def getConstraintSize = constraintRange.size
	def getFeatureSize = ecc.allNodes.size
	def isFeatureActive(id:String):Boolean = {
		if (getActiveConditionIndex(id).isEmpty) throw new Exception(id + " not found.")
		ExpressionHelper.evaluateTypeCorrectExpression(
			getActiveCondition(id).get, getValuation) == BoolLiteral(true)
	}
	def changeFeature(id:String, value:OptionValue) = {
		val cValue = ecc.convertOptionValue(value, id)
		config = config + (id -> cValue)
		valuationNeedsUpdate = true
		satisficationNeedsUpdate = true
		preTranslationNeedsUpdate = true
	}
	def getValuation:Map[String, Literal] = {
		if (valuationNeedsUpdate) updateValuation
		valuation
	}
	def convertSingleOptionValueToValuation(id:String, value:OptionValue):Iterable[(String, Literal)] =
		ecc.convertOptionValue(value, id) match {
			case SingleConfigValue(v) => 
				if (getFeatureFlavor(id) == Flavor.Bool)
					List((NodeHelper.toBoolVar(id), v))
				else {
					assert(getFeatureFlavor(id) == Flavor.Data)
					List((NodeHelper.toDataVar(id), v))
				}
			case DoubleConfigValue(b, v) => List((NodeHelper.toBoolVar(id), b), (NodeHelper.toDataVar(id), v))
		} 
	def getFeatureFlavor(id:String) = {
		ecc.allNodes(id).flavor 
	}
	def save(outFile:String) = {
		def getHeader = {
			val in = new BufferedReader(new FileReader(file))
			try {
				val configStartPattern = "cdl_configuration eCos".r
				val endPattern = "cdl_component|cdl_package|cdl_option|cdl_interface".r
				val sb = new StringBuilder
				var nextLine = in.readLine
				while(nextLine != null && configStartPattern.findFirstIn(nextLine).isEmpty) {
					sb ++= nextLine
					sb ++= "\n"
					nextLine = in.readLine
				}
				while(nextLine != null && endPattern.findFirstIn(nextLine).isEmpty) {
					sb ++= nextLine
					sb ++= "\n"
					nextLine = in.readLine
				}
				sb.toString
			}
			finally {
				in.close
			}
		}
		
		val header = getHeader
		val out = new BufferedWriter(new FileWriter(outFile))
		try {
			out.write(header)
			
			for((id, value) <- config) {
				val typeStr = ecc.allNodes(id).cdlType match {
					case CdlType.Package => "cdl_package"
					case CdlType.Component => "cdl_component"
					case CdlType.Interface => "cdl_interface"
					case CdlType.Option => "cdl_option"
				}
				out.write(typeStr)
				out.write(" ")
				out.write(id)
				out.write(" {\n\t")
				
				def encodeString(str:String):String = 
					str.map(_ match {
						case '\\' => "\\\\"
						case '\"' => "\\\""
						case '\'' => "\\\'"
						case '$' => "\\$"
						case c:Char => new String(Array(c))
					}).reduce(_ + _)
				
				def value2String(v:Literal):String = v match {
					case StringLiteral(s) => "\"" + encodeString(s) + "\""
					case IntLiteral(i) => i.toString 
					case EnumLiteral(v, t) => value2String(v)
					case BoolLiteral(true) => "1"
					case BoolLiteral(false) => "0"
					case RealLiteral(r) => r.toString
					case SetLiteral(values) => "\"" + values.map(encodeString).reduceLeft(_ + " " + _) + "\""
				}
				
				val userValue = value match {
					case SingleConfigValue(l) => "user_value " + value2String(l)
					case DoubleConfigValue(b, l) => "user_value " + value2String(b) + " " + value2String(l)
					case NoneConfigValue => ""
				}
				out.write(userValue)
				out.write("\n}\n\n")
			}
		}
		finally {
			out.close()
		}
	}
	
	def generateFix(constraintIndex:Int, strategy:Strategy):Iterable[DataFix] = {
		generateFixWithTime(constraintIndex, 1, strategy)._1
	}

	def generateFixWithTime(constraintIndex:Int, executionTimes:Int, strategy:Strategy):(Iterable[DataFix], Long) = {
		if (!constraintRange.contains(constraintIndex)) 
			throw new java.lang.IllegalArgumentException("constraint index out of range")
		fixConstraintWithTime(constraintIndex, executionTimes, strategy)
	}
	
	private def fixConstraintWithTime(constraintIndex:Int, executionTimes:Int, strategy:Strategy ):(Iterable[DataFix], Long) = {
		if (satisficationNeedsUpdate) checkConflictsWithIndex
		if (preTranslationNeedsUpdate) updateSMTPreTranslation
		val result = Timer.measureTime{
			val result = strategy.fix(preTranslation, constraintIndex, satisfiedConstraints)
			for (i <- 1 until executionTimes)
				strategy.fix(preTranslation, constraintIndex, satisfiedConstraints)
			result
		}
		(result, Timer.lastExecutionMillis / executionTimes)
	}

	
	def activateFeature(id:String, strategy:Strategy):Iterable[DataFix] = {
		activateFeatureWithTime(id, 1, strategy)._1
	}
	def activateFeatureWithTime(id:String, executionTimes:Int, strategy:Strategy):(Iterable[DataFix], Long) = {
		if (getActiveConditionIndex(id).isEmpty) 
			throw new java.lang.IllegalArgumentException("constraint index out of range")
		val constraintIndex = getActiveConditionIndex(id).get
		fixConstraintWithTime(constraintIndex, executionTimes, strategy)
	}
	
	def getActiveCondition(id:String) = getActiveConditionIndex(id).map(allConditions).map(_.getConstraint)

	
	private def updateSMTPreTranslation() { 
		preTranslation = new SMTPreTranslation(
			allConditions.map(_.getConstraint), 
			imlConstratints, 
			getValuation)
	}

	private val ecc:TypedEcc = loadEccFileAndInferTypes(file)
	private val imlConstratints:ImlConstraints = convertNodes(ecc, true)
	private val (allConditions, constraintRange, getActiveConditionIndex)
		:(IndexedSeq[ConstraintWithSource], immutable.Range, String=>Option[Int]) = {
		val allConstraints = Vector() ++ imlConstratints.allConstraints.filter(_.getConstraint != BoolLiteral(true))
		val orderedIds = Vector() ++ ecc.allNodes.keySet
		val activeConditionMap = (for (i <- 0 until orderedIds.size) yield ( orderedIds(i), i + allConstraints.size)).toMap
		(	
			allConstraints ++ orderedIds.map(id => ActiveIfCondition(imlConstratints.activeConditions(id), id)), 
			0 until allConstraints.size, 
			activeConditionMap.get _
		)
	}
		
		
	
	var config:Map[String, ConfigValue] = ecc.config
	private var valuationNeedsUpdate = true
	private var valuation:Map[String, Literal] = null
	private def updateValuation() {
		valuation = convertConfig(config, ecc, imlConstratints)._1
		valuationNeedsUpdate = false
	}
	private var satisficationNeedsUpdate = true
	private var satisfiedConstraints:Set[Int] = Set()
	private var unsatisfiedConstraints:Set[Int] = Set()
	private var preTranslationNeedsUpdate = true
	private var preTranslation:SMTPreTranslation = null
	
	private case class TypedEcc(allNodes:Map[String, Node], 
								types:Map[String, SingleType], 
								config:Map[String, ConfigValue],
								convertOptionValue:(OptionValue, String)=>ConfigValue)
	private def loadEccFileAndInferTypes(file:String):TypedEcc = {
		// load an ecc file
		val (orgNodes, eccFile) = parseEcc(file)
		val orgValues = eccFile.values.toMap
		val (nodeAnns, allTypeAnns) = parseAnnotations()
		val fileName = {
			val t = new java.io.File(file).getName; 
			val i = t.indexOf("."); 
			if (i >= 0) t.substring(0, i) else t
		}
		val annotatedNodes = nodeAnns.apply(orgNodes, fileName)
		val typeAnns = allTypeAnns.filter(orgNodes, fileName)
		
		
		// infer types and rewrite expressions
		val (nodes, types, rewriteFunc) = TypeHelper.getTypesAndRewriteNodes(annotatedNodes, orgValues, typeAnns.toTypeConstraints)
		val config = TypeHelper.convertConfig(orgValues, types, rewriteFunc)

		val allNodes = (org.kiama.rewriting.Rewriter.collectl { case n:Node => n } (nodes)).map(n => (n.id, n)).toMap
		
		def convertOptionValue(v:OptionValue, id:String) = TypeHelper.convertOptionValue(v, rewriteFunc(_, types(id)))
		
		TypedEcc(allNodes, types, config, convertOptionValue)
	}

	private def parseAnnotations() = {
		val annLexer = new AnnotationLexer(new FileReader(globalAnnotationPath))
		val annParser = new AnnotationParser(annLexer)
		annParser.parse()
		if (annParser.errors.size > 0) throw new Exception(annParser.errors.toString)
		(annParser.getNodeAnnotations, annParser.getTypeAnnotations)
	}

	private def parseEcc(fileName:String):(Iterable[Node], EccFile) = {
		import collection.JavaConversions._
		val eccLexer = new EccFullLexer(new FileReader(fileName))
		val eccParser = new EccFullParser(eccLexer)
		eccParser.parse()
		if (eccParser.errors.size > 0) throw new Exception(eccParser.errors.toString)
		val translatedNodes = NodeHelper.EccNodes2Nodes(eccParser.allNodes())
		(translatedNodes, eccParser.getEccFile())
	}


	private def convertNodes(ecc:TypedEcc, replacedSemanticVars:Boolean = false):ImlConstraints = 
		NodeHelper.typeCorrectNodes2Constraints(ecc.allNodes, ecc.types, replacedSemanticVars)

	private def convertConfig(config:Map[String, ConfigValue], 
							  ecc:TypedEcc, 
							  imlConstratints:ImlConstraints)
							:(Map[String, Literal], Map[String, Literal]) = 
		NodeHelper.values2configuration(config, ecc.allNodes, ecc.types, imlConstratints.defaults, imlConstratints.semanticVars)

	private def checkConflictsWithIndex() {
		val satisfiedConstraints = mutable.Set[Int]()
		val unsatisfiedConstraints = mutable.Set[Int]()
		for (i <- constraintRange) {
			val result = ExpressionHelper.evaluateTypeCorrectExpression(allConditions(i).getConstraint, getValuation)
			assert(result.isInstanceOf[BoolLiteral])
			if (result == BoolLiteral(true)) 
				satisfiedConstraints += i
			else
				unsatisfiedConstraints += i
		}
		this.satisfiedConstraints = satisfiedConstraints
		this.unsatisfiedConstraints = unsatisfiedConstraints
		satisficationNeedsUpdate = false
	}
}

class SMTPreTranslation(allConstraints:IndexedSeq[Expression], 
						imlConstratints:ImlConstraints, 
						config:Map[String, Literal]) {
	var printDetailedTime = false
	private def printDetailedTime[T](id:String)(func: => T):T = {
		if (printDetailedTime) Timer.printTime(id)(func) else func
	}

	val translator = new Expression2SMT(allConstraints ++ config.values, imlConstratints.types)
	val smtConstraints = allConstraints.map(translator.convert)
	val constraint2varsMap = mutable.Map[Int, Set[String]]()
	val var2ConstraintsMap = mutable.Map[String, Set[Int]]()
	for (i <- 0 until allConstraints.size) {
		val vars = org.kiama.rewriting.Rewriter.collects { case IdentifierRef(id) => id } (allConstraints(i))
		for (v <- vars) {
			constraint2varsMap put (i, constraint2varsMap.getOrElse(i, Set()) + v)
			var2ConstraintsMap put (v, var2ConstraintsMap.getOrElse(v, Set()) + i)
		}
	}
	def getTypeInExpr(c:Expression):Set[Type] = {
		import org.kiama.rewriting.Rewriter._
		val allTypes = mutable.Set[Type]()
		rewrite(everywhere{query{
			case l:Literal => allTypes += ExpressionHelper.getType(l, Map())
		}})(c)
		allTypes
	}
	val constraint2TypesMap : Map[Int, Set[Type]] = (0 until allConstraints.size).map(i => (i, getTypeInExpr(allConstraints(i)))).toMap

	
	def fixWithIgnorance(toFix:Int) = fix(toFix, Set())
	def fixWithElimination(toFix:Int, toBeEnsuredConstraints:Set[Int]) = {
		val modifiableVars = constraint2varsMap.getOrElse(toFix, Set())
		val relatedConstraints = modifiableVars.map(var2ConstraintsMap).flatten.toSet & (toBeEnsuredConstraints + toFix)
		import org.kiama.rewriting.Rewriter._
		def replaceVariables:Expression=>Expression = rewrite{everywhere{rule{
			case IdentifierRef(x) if !modifiableVars.contains(x) => config(x)
		}}}
		val replacedConstraints = relatedConstraints.map(allConstraints).map(replaceVariables)
		assert ( collects { case IdentifierRef(x) => x } (replacedConstraints) == modifiableVars )
		val replacedSMTConstraints = replacedConstraints.map(translator.convert)
		assert ( collects { case x:SMTVarRef => x.id } (replacedSMTConstraints) == modifiableVars )
		val slicedConfig = config.filterKeys(modifiableVars.contains)
		val slicedSMTConfig = slicedConfig.mapValues(translator.convert).asInstanceOf[Map[String, SMTLiteral]]
		val slicedTypes = imlConstratints.types.filterKeys(modifiableVars.contains)
		val (slicedSMTTypes, slicedSMTFuncsInVars) = translator.convertTypes(slicedTypes)
		val typesInExprPair = relatedConstraints.map(constraint2TypesMap).flatten.map(t => translator.type2SMTTypeAndFunc(t)).unzip
		val slicedSMTTypesToDecl = typesInExprPair._1 ++ slicedSMTTypes.values
		val slicedSMTFuncsToDecl = slicedSMTFuncsInVars ++ typesInExprPair._2.flatten
		
		val diagnoses = 
			FixGenerator.generateSimpleDiagnoses(slicedSMTConfig, modifiableVars, replacedSMTConstraints, slicedSMTTypes, slicedSMTFuncsToDecl, slicedSMTTypesToDecl)
		
		
		val fixes = FixGenerator.simpleDiagnoses2Fixes(slicedConfig, replacedConstraints, diagnoses)
		fixes
	}
	
	def fix(toFix:Int, toBeEnsuredConstraints:Set[Int]) = {
		val (slicedConfig, slicedSMTConfig, slicedVars, slicedConstraints, slicedSMTConstraints, slicedSMTTypes, slicedSMTFuncsToDecl, slicedSMTTypesToDecl) = printDetailedTime("Slicing") {
			def expandVars(allVars:Set[String], allConstraints:Set[Int], newVars:Set[String]):(Set[String], Set[Int]) = {
				val relatedConstraints = newVars.map(var2ConstraintsMap).flatten.toSet
				val newConstraints = (relatedConstraints -- allConstraints) & (toBeEnsuredConstraints + toFix)
				if (newConstraints.size > 0)
					expandConstraints(allVars ++ newVars, allConstraints, newConstraints)
				else
					(allVars ++ newVars, allConstraints)
			}
			def expandConstraints(allVars:Set[String], allConstraintIndexes:Set[Int], newConstraints:Set[Int]):(Set[String], Set[Int]) = {
				val relatedVars = newConstraints.map(constraint2varsMap.getOrElse(_, Set())).flatten.toSet
				val newVars = relatedVars -- allVars
				if (newVars.size > 0)
					expandVars(allVars, allConstraintIndexes ++ newConstraints, newVars)
				else
					(allVars, allConstraintIndexes ++ newConstraints)
			}
			val (slicedVars, slicedConstraintIndexes) = expandConstraints(Set(), Set(), Set(toFix))
			val slicedConstraints = slicedConstraintIndexes.map(allConstraints)
			val slicedSMTConstraints = slicedConstraintIndexes.map(smtConstraints)
			assert ( org.kiama.rewriting.Rewriter.collects { 
				case x:IdentifierRef => x.id 
			} (slicedConstraints) == slicedVars )
			assert ( org.kiama.rewriting.Rewriter.collects { 
				case x:SMTVarRef => x.id 
			} (slicedSMTConstraints) == slicedVars )
			
			if (printDetailedTime) print("sliced size " + (slicedConstraints.size.toDouble / allConstraints.size.toDouble * 100.0) + "%--")

			val slicedConfig = config.filterKeys(slicedVars.contains)
			val slicedSMTConfig = slicedConfig.mapValues(translator.convert).asInstanceOf[Map[String, SMTLiteral]]
			val slicedTypes = imlConstratints.types.filterKeys(slicedVars.contains)
			val (slicedSMTTypes, slicedSMTFuncsInVars) = translator.convertTypes(slicedTypes)
			val typesInExprPair = slicedConstraintIndexes.map(constraint2TypesMap).flatten.map(t => translator.type2SMTTypeAndFunc(t)).unzip
			val slicedSMTTypesToDecl = typesInExprPair._1 ++ slicedSMTTypes.values
			val slicedSMTFuncsToDecl = slicedSMTFuncsInVars ++ typesInExprPair._2.flatten
				
			(slicedConfig, slicedSMTConfig, slicedVars, slicedConstraints, slicedSMTConstraints, slicedSMTTypes, slicedSMTFuncsToDecl, slicedSMTTypesToDecl)
		}
		val diagnoses = printDetailedTime("Generating diagnoses") {
			FixGenerator.generateSimpleDiagnoses(slicedSMTConfig, slicedVars, slicedSMTConstraints, slicedSMTTypes, slicedSMTFuncsToDecl, slicedSMTTypesToDecl)
		}
		
		val fixes = printDetailedTime("Converting to fixes") {
			FixGenerator.simpleDiagnoses2Fixes(slicedConfig, slicedConstraints, diagnoses)
		}
		
		fixes
	}
}
