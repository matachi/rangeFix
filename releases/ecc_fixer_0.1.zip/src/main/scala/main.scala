package ca.uwaterloo.gsd.rangeFix
import java.io._
import collection._

object Main {
	
	var executionTimes = 1
	var printDetailedTime = false
	var measureTime = false
	
	def printDetailedTime[T](id:String)(func: => T):T = {
		if (printDetailedTime) Timer.printTime(id)(func) else func
	}
	
	def measureTime[T](func: => T):T = {
		if (measureTime) {
			val result = Timer.measureTime{
				val result = func
				for (i <- 1 until executionTimes)
					func
				result
			}
			println("Execution Time: " + (Timer.lastExecutionMillis / executionTimes) + "ms from " + executionTimes + " executions")
			result
		} else func
	}
	
	def findArgIndex(args:Seq[String], tgts:Iterable[String]):Int = {
		for (t <- tgts) {
			val i = args.indexOf(t)
			if (i >= 0) return i
		}
		return -1
	}
	
	// Execution form: 
	// Summary of arguments
	// -verbose or -v: print detailed execution time
	// -time [n] or -t [n]: execute the generation n times to get the average execution time
	// -annotation [path] or -ann [path]: specify the path to the annotation file to fix type error in eCos file
	// -activate or -a: activate a feature
	// TODO:
	// * apply the fix after user choice
	// * set Z3 path to a suitable location
	def main(args:Array[String]) {
	
		if (!new java.io.File(CompilationOptions.Z3_PATH).exists()) {
			println("Cannot find Z3.")
			return
		}


		val cArgs = mutable.ListBuffer() ++ args
		
		if (cArgs.contains("-verbose") | cArgs.contains("-v")) printDetailedTime = true
		else {
			val timeIndex = findArgIndex(cArgs, List("-time", "-t"))
			if (timeIndex >= 0) {
				measureTime = true
				val numberPattern = "\\d+".r
				if (cArgs.size > timeIndex + 1 && numberPattern.findFirstIn(cArgs(timeIndex + 1)) == Some(cArgs(timeIndex + 1))) {
					executionTimes = cArgs(timeIndex + 1).toInt
					cArgs.remove(timeIndex + 1)
				}
				cArgs.remove(timeIndex)
			}
		}
		
		val annotationIndex = findArgIndex(cArgs, List("-annotation", "-ann"))
		if (annotationIndex >= 0) {
			globalAnnotationPath = cArgs(annotationIndex + 1)
			cArgs.remove(annotationIndex)
			cArgs.remove(annotationIndex)
		}
		
		val eccFile = cArgs.filter(!_.startsWith("-")).head

		try {
			val activateIndex = {val a = cArgs.indexOf("-activate"); if (a < 0) cArgs.indexOf("-a") else a}
			if (activateIndex >= 0) {
				val id = cArgs(activateIndex + 1)
				activateSimple(eccFile, id)
				return
			}
			
			interactiveSimple(eccFile)
		}
		catch {
			case e:Exception => e.printStackTrace()
		}
	}
	
	def interactiveSimple(file:String) {
		val eccManipulator = new EccManipulator(file, globalAnnotationPath)
		val satisfiedConstraints = eccManipulator.getSatisfiedConstraintIndexes
		val unsatisfiedConstraints = eccManipulator.getUnsatisfiedConstraintIndexes

		// val ecc = loadEccFileAndInferTypes(file)
		
		// // translate expressions to constraints
		// val imlConstratints = convertEcc(ecc, true)
		
		// // rewrite the configuration
		// val (config, _) = convertConfig(ecc, imlConstratints)
		
		// //convert to Z3
		// val allConstraints = imlConstratints.allConstraints.filter(_.getConstraint != BoolLiteral(true)).toArray[ConstraintWithSource]
		
		// val smtPreTranslation = new SMTPreTranslation(allConstraints.map(_.getConstraint), imlConstratints, config)
		
		
		// // check conflicts
		// val (satisfiedConstraints, unsatisfiedConstraints) = checkConflictsWithIndex(config, allConstraints)
		
		if (unsatisfiedConstraints.size == 0) {
			println("This file contains no conflict.")
			return
		}
		var i = 0
		for (sci <- unsatisfiedConstraints) {
			i += 1
			println(i.toString + ". " + eccManipulator.getConstraint(sci).getSource() + " is violated.")
		}
		
		// fix each conflict
		i = 0
		for (sci <- unsatisfiedConstraints) {
			val fixes = measureTime { eccManipulator.generateFix(sci, PropagationStrategy) }

			// print fixes
			i += 1
			println("Fixes for " + i.toString)
			if (fixes.size == 0) 
				println("\tNo fix can be found")
			else
				fixes.foreach(f => println("\t" + f))

			
		}
		
	}

	def activateSimple(file:String, id:String) {
		val eccManipulator = new EccManipulator(file, globalAnnotationPath)
		val satisfiedConstraints = eccManipulator.getSatisfiedConstraintIndexes
		val unsatisfiedConstraints = eccManipulator.getUnsatisfiedConstraintIndexes
		val optActiveConstraint = eccManipulator.getActiveCondition(id)
		if (optActiveConstraint.isEmpty) {
			println("Feature " + id + " cannot be found.")
			return
		}
		if (eccManipulator.isFeatureActive(id)) {
			println("Feature " + id + " is already active.")
			return
		}
		
		val fixes = measureTime { eccManipulator.activateFeature(id, PropagationStrategy) }

	
		// val ecc = loadEccFileAndInferTypes(file)
		
		// // translate expressions to constraints
		// val imlConstratints = convertEcc(ecc, true)
		
		// // rewrite the configuration
		// val (config, _) = convertConfig(ecc, imlConstratints)

		// // prepare the constraint
		// val optActiveConstraint = imlConstratints.activeConditions.get(id)
		// if (optActiveConstraint.isEmpty) {
			// println("Feature " + id + " cannot be found.")
			// return
		// }
		// val activeConstraint = ActiveIfCondition(optActiveConstraint.get, id)
		// val allConstraints = Vector(activeConstraint) ++ imlConstratints.allConstraints.filter(_.getConstraint != BoolLiteral(true))
		
		// //convert to Z3
		// val smtPreTranslation = new SMTPreTranslation(allConstraints.map(_.getConstraint), imlConstratints, config)
		
		// val (satisfiedConstraints, unsatisfiedConstraints) = checkConflictsWithIndex(config, allConstraints)
		
		// if (!unsatisfiedConstraints.contains(0)) {
			// println("Feature " + id + " is already active.")
		// }
		
		// print fixes
		if (fixes.size == 0) 
			println("It is not possible to activate this feature without un/loading packages.")
		else
			fixes.foreach(f => println("\t" + f))
		
		
	}

	var globalAnnotationPath = "testfiles/realworld/allModels.annotation"

	private def parseAnnotations() = {
		val annLexer = new AnnotationLexer(new FileReader(globalAnnotationPath))
		val annParser = new AnnotationParser(annLexer)
		annParser.parse()
		if (annParser.errors.size > 0) throw new Exception(annParser.errors.toString)
		(annParser.getNodeAnnotations, annParser.getTypeAnnotations)
	}
	
	
	private def parseEcc(fileName:String):(Iterable[Node], EccFile) = {
		import collection.JavaConversions._
		val eccLexer = new EccFullLexer(new FileReader(fileName))
		val eccParser = new EccFullParser(eccLexer)
		eccParser.parse()
		if (eccParser.errors.size > 0) throw new Exception(eccParser.errors.toString)
		val translatedNodes = NodeHelper.EccNodes2Nodes(eccParser.allNodes())
		(translatedNodes, eccParser.getEccFile())
	}

	case class TypedEcc(allNodes:Map[String, Node], types:Map[String, SingleType], values:Map[String, ConfigValue])

	private def loadEccFileAndInferTypes(file:String):TypedEcc = {
		// load an ecc file
		val (orgNodes, eccFile) = parseEcc(file)
		val orgValues = eccFile.values.toMap
		val (nodeAnns, allTypeAnns) = parseAnnotations()
		val fileName = {
			val t = new java.io.File(file).getName; 
			val i = t.indexOf("."); 
			if (i >= 0) t.substring(0, i) else t
		}
		val annotatedNodes = nodeAnns.apply(orgNodes, fileName)
		val typeAnns = allTypeAnns.filter(orgNodes, fileName)
		
		
		// infer types and rewrite expressions
		val (nodes, types, values) = TypeHelper.getTypesAndRewrite(annotatedNodes, orgValues, typeAnns.toTypeConstraints)

		val allNodes = (org.kiama.rewriting.Rewriter.collectl { case n:Node => n } (nodes)).map(n => (n.id, n)).toMap
		
		TypedEcc(allNodes, types, values)
	}
	
	
	private def convertEcc(ecc:TypedEcc, replacedSemanticVars:Boolean = false):ImlConstraints = 
		NodeHelper.typeCorrectNodes2Constraints(ecc.allNodes, ecc.types, replacedSemanticVars)
		
	private def convertConfig(ecc:TypedEcc, 
							  imlConstratints:ImlConstraints)
							:(Map[String, Literal], Map[String, Literal]) = 
		NodeHelper.values2configuration(ecc.values, ecc.allNodes, ecc.types, imlConstratints.defaults, imlConstratints.semanticVars)
		
	private def checkConflicts(config:Map[String, Literal], 
							   constraints:Iterable[ConstraintWithSource]):
							  (Iterable[ConstraintWithSource], Iterable[ConstraintWithSource]) = {
		val satisfiedConstraints = new mutable.ListBuffer[ConstraintWithSource]
		val unsatisfiedConstraints = new mutable.ListBuffer[ConstraintWithSource]
		for (sourceConstrint <- constraints) {
			val result = ExpressionHelper.evaluateTypeCorrectExpression(sourceConstrint.getConstraint, config)
			assert(result.isInstanceOf[BoolLiteral])
			if (result == BoolLiteral(true)) 
				satisfiedConstraints += sourceConstrint
			else
				unsatisfiedConstraints += sourceConstrint
		}
		(satisfiedConstraints, unsatisfiedConstraints)
	}
	
	class SMTPreTranslation(allConstraints:IndexedSeq[Expression], imlConstratints:ImlConstraints, config:Map[String, Literal]) {
		val translator = new Expression2SMT(allConstraints ++ config.values, imlConstratints.types)
		val smtConstraints = allConstraints.map(translator.convert)
		val constraint2varsMap = mutable.Map[Int, Set[String]]()
		val var2ConstraintsMap = mutable.Map[String, Set[Int]]()
		for (i <- 0 until allConstraints.size) {
			val vars = org.kiama.rewriting.Rewriter.collects { case IdentifierRef(id) => id } (allConstraints(i))
			for (v <- vars) {
				constraint2varsMap put (i, constraint2varsMap.getOrElse(i, Set()) + v)
				var2ConstraintsMap put (v, var2ConstraintsMap.getOrElse(v, Set()) + i)
			}
		}
		
		def fix(toFix:Int, toBeEnsuredConstraints:Set[Int]) = {
			val (slicedConfig, slicedSMTConfig, slicedVars, slicedConstraints, slicedSMTConstraints, slicedSMTTypes, slicedSMTFuncs) = printDetailedTime("Slicing") {
				def expandVars(allVars:Set[String], allConstraints:Set[Int], newVars:Set[String]):(Set[String], Set[Int]) = {
					val relatedConstraints = newVars.map(var2ConstraintsMap).flatten.toSet
					val newConstraints = (relatedConstraints -- allConstraints) & (toBeEnsuredConstraints + toFix)
					if (newConstraints.size > 0)
						expandConstraints(allVars ++ newVars, allConstraints, newConstraints)
					else
						(allVars ++ newVars, allConstraints)
				}
				def expandConstraints(allVars:Set[String], allConstraintIndexes:Set[Int], newConstraints:Set[Int]):(Set[String], Set[Int]) = {
					val relatedVars = newConstraints.map(constraint2varsMap.getOrElse(_, Set())).flatten.toSet
					val newVars = relatedVars -- allVars
					if (newVars.size > 0)
						expandVars(allVars, allConstraintIndexes ++ newConstraints, newVars)
					else
						(allVars, allConstraintIndexes ++ newConstraints)
				}
				val (slicedVars, slicedConstraintIndexes) = expandConstraints(Set(), Set(), Set(toFix))
				val slicedConstraints = slicedConstraintIndexes.map(allConstraints)
				val slicedSMTConstraints = slicedConstraintIndexes.map(smtConstraints)
				assert ( org.kiama.rewriting.Rewriter.collects { 
					case x:IdentifierRef => x.id 
				} (slicedConstraints) == slicedVars )
				assert ( org.kiama.rewriting.Rewriter.collects { 
					case x:SMTVarRef => x.id 
				} (slicedSMTConstraints) == slicedVars )
				
				if (printDetailedTime) print("sliced size " + (slicedConstraints.size.toDouble / allConstraints.size.toDouble * 100.0) + "%--")

				val slicedConfig = config.filterKeys(slicedVars.contains)
				val slicedSMTConfig = slicedConfig.mapValues(translator.convert).asInstanceOf[Map[String, SMTLiteral]]
				val slicedTypes = imlConstratints.types.filterKeys(slicedVars.contains)
				val (slicedSMTTypes, slicedSMTFuncs) = translator.convertTypes(slicedTypes)
					
				(slicedConfig, slicedSMTConfig, slicedVars, slicedConstraints, slicedSMTConstraints, slicedSMTTypes, slicedSMTFuncs)
			}
			val diagnoses = printDetailedTime("Generating diagnoses") {
				FixGenerator.generateSimpleDiagnoses(slicedSMTConfig, slicedVars, slicedSMTConstraints, slicedSMTTypes, slicedSMTFuncs)
			}
			
			val fixes = printDetailedTime("Converting to fixes") {
				FixGenerator.simpleDiagnoses2Fixes(slicedConfig, slicedConstraints, diagnoses)
			}
			
			fixes
		}
	}
	
	
	private def checkConflictsWithIndex(config:Map[String, Literal], 
							   constraints:IndexedSeq[ConstraintWithSource]):
							  (Set[Int], Set[Int]) = {
		val satisfiedConstraints = mutable.Set[Int]()
		val unsatisfiedConstraints = mutable.Set[Int]()
		for (i <- 0 until constraints.size) {
			val result = ExpressionHelper.evaluateTypeCorrectExpression(constraints(i).getConstraint, config)
			assert(result.isInstanceOf[BoolLiteral])
			if (result == BoolLiteral(true)) 
				satisfiedConstraints += i
			else
				unsatisfiedConstraints += i
		}
		(satisfiedConstraints, unsatisfiedConstraints)
	}
							  
	
	def interactive(file:String) {
		val ecc = loadEccFileAndInferTypes(file)
		
		// translate expressions to constraints
		val imlConstratints = convertEcc(ecc)
		
		// rewrite the configuration
		val (config, semanticConfig) = convertConfig(ecc, imlConstratints)
		val allConfig = config ++ semanticConfig
		
		// check conflicts
		val (satisfiedConstraints, unsatisfiedConstraints) = 
			checkConflicts(allConfig, imlConstratints.allConstraints)
		
		if (unsatisfiedConstraints.size == 0) {
			println("This file contains no conflict.")
			return
		}
		var i = 0
		for (sc <- unsatisfiedConstraints) {
			i += 1
			println(i.toString + ". " + sc.getSource() + " is violated.")
		}
		
		// fix each conflict
		i = 0
		for (sc <- unsatisfiedConstraints) {
			val (smtConfig, changeableVars, smtConstraints, translator, syntcConstraints, funcsToDeclare) = printDetailedTime("Converting to Z3") {
				//   translate expressions to SMTExpressions
				val syntcConstraints = satisfiedConstraints.map(_.getConstraint) ++ List(sc.getConstraint)
				val semanticConstraints = imlConstratints.semanticVars.map(pair => IdentifierRef(pair._1) === pair._2)
				val allConstraints = syntcConstraints ++ semanticConstraints
				val translator = new Expression2SMT(allConstraints ++ config.values, imlConstratints.types)
				val smtConstraints = allConstraints.map(translator.convert)
				//   translate configuration to SMTConfiguration
				val smtConfig = allConfig.mapValues(translator.convert(_).asInstanceOf[SMTLiteral]) 
				//   generate fix
				val allVars = org.kiama.rewriting.Rewriter.collects { case n:SMTVarRef => n.id } (smtConstraints) 
				val changeableVars = allVars -- semanticConfig.keySet
				//val filteredSConfig = semanticConfig.filterKeys(allVars.contains(_))
				//val filteredSVars = imlConstratints.semanticVars.filterKeys(allVars.contains(_))
				
				(smtConfig, changeableVars, smtConstraints, translator, syntcConstraints, translator.allFunctions)
			}
			
			val diagnoses = printDetailedTime("Generating diagnoses") {
				FixGenerator.generateDiagnoses(smtConfig, changeableVars, imlConstratints.semanticVars.keySet, smtConstraints, 	translator.SMTTypes(), funcsToDeclare)
			}
			
			val fixes = printDetailedTime("Converting to fixes") {
				FixGenerator.diagnoses2Fixes(config, syntcConstraints, 
							imlConstratints.semanticVars, semanticConfig, diagnoses)
			}

			// print fixes
			i += 1
			println("Fixes for " + i.toString)
			if (fixes.size == 0) 
				println("\tNo fix can be found")
			else
				fixes.foreach(f => println("\t" + f))

			
		}
	}
	
	def random() {
		// load an ecc file
		// infer types
		// rewrite expressions
		// translate expressions to constraints
		// generate a correct configurations
		// mutate the configuration until we got a conflict
		// fix the conflict
	}
}
