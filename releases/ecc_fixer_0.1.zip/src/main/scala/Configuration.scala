package ca.uwaterloo.gsd.rangeFix

object CompilationOptions {
	import ConditionalCompilation._
	type ENFORCE_BOOLEAN = FALSE
	type ENUM_CONVERTIBLE = FALSE
	type TRACE_TYPE_PROPAGATION = FALSE
	type CONVERT_REAL_TO_INT = TRUE
	val THREAD_NUMBER = 2
	val Z3_PATH = """c:\Program Files\Microsoft Research\Z3-3.2\bin_mt\z3.exe""" 
}
