package ca.uwaterloo.gsd.rangeFix
import collection.mutable
import collection._

object FixGenerator {
  
    val guardPrefix = "__gd__"
	type Diagnosis = Set[String]
	type SemanticDiagnosis = (Diagnosis, Diagnosis)
	type SemanticDiagnoses = Iterable[SemanticDiagnosis]
	
	private def toGuardVar(v:String):String = guardPrefix + v
	private def toNormalVar(v:String):String = v.substring(guardPrefix.size)

	private def conf2constr(v:String, l:SMTLiteral):SMTExpression = {
		val guardVar = toGuardVar(v)
		(!SMTVarRef(guardVar)) | (SMTVarRef(v) === l)
	}
	
	def generateSimpleDiagnoses(configuration:Map[String, SMTLiteral], 
								varSet:Set[String], 
								constraints: Iterable[SMTExpression],
								types:Map[String, SMTType], 
								funcsToDeclare:Iterable[SMTFuncDefine],
								optTypesToDeclare:Set[SMTType] = null):Iterable[Diagnosis] = {
		import org.kiama.rewriting.Rewriter._
		val typesToDeclare = if (optTypesToDeclare == null) varSet.map(v => types(v)) else optTypesToDeclare
		val z3 = new Z3()
		z3.enableUnsatCore
		try {
			assert ( collects { case x:SMTVarRef => x.id } (constraints) == varSet )
			z3.declareTypes(typesToDeclare)
			funcsToDeclare.foreach(z3.declareFunc)
			z3.declareVariables(varSet.map(v=>(v, types(v))))
			z3.declareVariables(varSet.map(v => (toGuardVar(v), SMTBoolType)))
			for (c <- constraints)
				z3.assertConstraint(c)
			for (v <- varSet)
				z3.assertConstraint(conf2constr(v, configuration(v)))
			def getCore(removedVars:Traversable[String]):Option[List[String]] = z3.getUnsatCore(varSet.map(v=>toGuardVar(v)) -- removedVars).map(_.toList)
			val diagnoses = (new HSDAG[String]()).getDiagnoses(getCore)
			diagnoses.map(_.map(toNormalVar).toSet)
		}
		finally {
			z3.exit()
		}
	}
		
	
	// configuration by default includes all semantic vars and syntatic vars
	// constraints include semantic var definitions
	def generateDiagnoses(configuration:Map[String, SMTLiteral], 
						  changeableVars:Set[String], 
						  semanticVars:Set[String],
						  constraints:Iterable[SMTExpression],
						  types:Map[String, SMTType],
						  funcsToDeclare:Iterable[SMTFuncDefine]):SemanticDiagnoses = {
		import org.kiama.rewriting.Rewriter._
		val z3 = new Z3()
		z3.enableUnsatCore
		try {
			val varSet = changeableVars ++ semanticVars
			assert ( collects { case x:SMTVarRef => x.id } (constraints) == varSet )
			val allTypes = varSet.map(v => types(v))
			z3.declareTypes(allTypes)
			funcsToDeclare.foreach(z3.declareFunc)
			z3.declareVariables(varSet.map(v=>(v, types(v))))
			z3.declareVariables(varSet.map(v => (toGuardVar(v), SMTBoolType)))
			for (c <- constraints)
				z3.assertConstraint(c)
			for (v <- varSet)
				z3.assertConstraint(conf2constr(v, configuration(v)))
			def getCore(changeableVars:Set[String])(removedVars:Traversable[String]):Option[List[String]] = z3.getUnsatCore(changeableVars.map(v=>toGuardVar(v)) -- removedVars).map(_.toList)
			val semanticDiagnoses = (new HSDAG[String]()).getDiagnoses(getCore(semanticVars))
			(for(sd <- semanticDiagnoses) yield {
				val nsd = sd.map(toNormalVar(_))
				val fixedVars = semanticVars.toSet -- nsd
				z3.push()
				for (v <- fixedVars)
					z3.assertConstraint(toGuardVar(v))
				val diagnoses = (new HSDAG[String]()).getDiagnoses(getCore(changeableVars))
				z3.pop()
				(diagnoses.map(d=>(d.map(toNormalVar(_)).toSet, nsd.toSet)))
			} ).flatten
		}
		finally {
			z3.exit()
		}
	}
	
	def simpleDiagnoses2Fixes(configuration:Map[String, Literal],
							  constraints:Iterable[Expression], 
							  ds:Iterable[Diagnosis]):Iterable[DataFix] = {
		import org.kiama.rewriting.Rewriter._
		val fixconstraints = 
			for(d <- ds) yield {
				constraints.map ( c => {
					val replaced = rewrite(everywheretd(repeat(rule{
						case IdentifierRef(id) if (!d.contains(id)) => configuration(id)
					} )))(c)
					val result = ExpressionHelper.simplify(replaced)
					assert( result != BoolLiteral(false) )
					result
				} ).filter(_ != BoolLiteral(true))
			}
			
		fixconstraints.map(constraint2DataFix(_))						
	}
	
	def diagnoses2Fixes(configuration:Map[String, Literal],
						constraints:Iterable[Expression], // may contain semantic vars
						semanticVars:Map[String, Expression],
						semanticVarValues:Map[String, Literal],
						ds:SemanticDiagnoses):Iterable[DataFix] = {
		import org.kiama.rewriting.Rewriter._
		
		val diagMap = mutable.Map[Diagnosis, Set[Diagnosis]]()
		for ((synt, semtc) <- ds) {
			diagMap.put(synt, diagMap.getOrElse(synt, Set()) + semtc)
		}
		val fixconstraints = 
			for ((synt, semntcs) <- diagMap) yield {
				//semantic part
				assert(semntcs.size > 0)
				val semntcsUnion = semntcs.reduce(_ ++ _)
				def svars2Constrts(svars:Diagnosis):Iterable[Expression] = {
					svars.map(v => IdentifierRef(v) === semanticVarValues(v))
				}
				val fixedSemntcConstrts = svars2Constrts(semanticVars.keySet -- semntcsUnion)
				val nonFixedConstraints = 
				if (semntcs.size > 1)
					List(semntcs.map(d => semntcsUnion -- d).map(svars => {
						assert(svars.size > 0)
						svars2Constrts(svars).reduce(_ & _)
					} ).reduce(_ | _))
				else List()
				val semntcConstrts = fixedSemntcConstrts ++ nonFixedConstraints
				
				//syntactic & semantic part
				val syntConstrts = (constraints ++ semntcConstrts).map ( c => {
					val replaced = rewrite(everywheretd(repeat(rule{
						case IdentifierRef(id) if (!synt.contains(id) && !semanticVars.contains(id)) => configuration(id)
						case IdentifierRef(id) if (semanticVars.contains(id)) => semanticVars(id)
					} )))(c)
					val result = ExpressionHelper.simplify(replaced)
					assert( result != BoolLiteral(false) )
					result
				} ).filter(_ != BoolLiteral(true))
				
				syntConstrts 
			}

		fixconstraints.map(constraint2DataFix(_))						
	}

	private def constraint2DataFix(constraints:Iterable[Expression]):DataFix = { 
		type Clause = Map[Expression, Boolean]
		
		def clause2GExpr(c:Clause) = c.foldLeft[Expression](BoolLiteral(true))((expr, pair) => {
			val unitExpr = if (pair._2) pair._1 else Not(pair._1)
			if (expr == BoolLiteral(true)) unitExpr else Or(expr, unitExpr)
		} )
		def toCNF(constraint:Expression, expected:Boolean = true):List[Clause] = {
			def times(fs1:List[Clause], fs2:List[Clause]):List[Clause] = {
				val result = 
					(for{f1 <- fs1
						f2 <- fs2
						if (f1.forall(pair => {val (e,b1) = pair; val b2= f2.get(e); b2==None || b2.get==b1}))}
						yield f1 ++ f2)
				simplifyCNF(result)
			}
			constraint match {
				case Not(e) => toCNF(e, !expected)
				case And(e1, e2) => 
					if (expected) {
						val fs1:List[Clause] = toCNF(e1, true)
						val fs2:List[Clause] = toCNF(e2, true)
						simplifyCNF(fs1 ++ fs2)
					} 
					else {
						toCNF(Or(Not(e1), Not(e2)), true)
					}
				case Or(e1, e2) =>
					if (expected) times(toCNF(e1, true), toCNF(e2, true))
					else toCNF(And(Not(e1), Not(e2)), true)
				case Implies(e1, e2) =>
					toCNF(Or(Not(e1), e2))
				case e:Expression => {
					List(Map(e -> expected))
				}
			}
		}
		def simplifyCNF(cnf:Iterable[Clause]) = {
			val toVisitClauses = mutable.Map[Expression, Boolean]() ++ cnf.filter(_.size == 1).map(_.head)
			val visitedClauses = mutable.Map[Expression, Boolean]()
			def removeContradict(cs:Iterable[Clause]):Iterable[Clause] = 
				if (toVisitClauses.size > 0) {
					val (expr, b):(Expression, Boolean) = toVisitClauses.head
					val resultCs = cs.map(c => 
						if (c.get(expr) == Some(!b)) {
							val result = c - expr 
							if ( result.size == 0 ) { //the whole CNF is false
								return List(Map())
							}
							if (result.size == 1) {
								if (visitedClauses.contains(result.head._1))
									assert(visitedClauses(result.head._1) == result.head._2)
								else
									toVisitClauses += result.head
							}
							result
						} 
						else c 
					)
					toVisitClauses -= expr
					visitedClauses put (expr, b)
					removeContradict(resultCs)
				}
				else cs
			
		
			def included(small:Clause, big:Clause):Boolean = {
				small.forall(pair => {val vb = big.get(pair._1); vb.isDefined && vb.get == pair._2})
			}
			var result = List[Clause]()
			removeContradict(cnf).foreach( f => {
				def filter(result:List[Clause]):List[Clause] = 
					if (result.isEmpty) List(f)
					else if (included(f, result.head)) filter(result.tail)
					else if (included(result.head, f)) result
					else result.head::(filter(result.tail))
				result = filter(result)
			} )
			result
		}
		
		if (constraints.size == 0) return new DataFix(List())
		
		val orgCNF = constraints.map(toCNF(_)).flatten
		val cnf = simplifyCNF(orgCNF)
		type Pair = (Clause, Set[String])
		val cnfVars:List[Pair] = cnf.map(clause => (clause, 
			clause.keySet.map(org.kiama.rewriting.Rewriter.collects {case IdentifierRef(id:String) => id}(_)).flatten))
		
		// find all clauses that share the same set of variables as cur
		def separateEqClass(cur:Pair, remainingClauses:Traversable[Pair]):(List[Pair], List[Pair]) = {
			val toBeAdded = mutable.ListBuffer[Pair]()
			var remaining = List[Pair]()
			var result = mutable.ListBuffer[Pair](cur)
			for(p <- remainingClauses) {
				if (!(cur._2 & p._2).isEmpty) {
					toBeAdded += p
				}
				else {
					remaining = p::remaining
				}
			}
			while (toBeAdded.size > 0) {
				val p = toBeAdded.head
				val (newToBeAdded, newRemaining) = separateEqClass(p, remaining)
				assert(newToBeAdded.head == p)
				remaining = newRemaining
				toBeAdded ++= newToBeAdded.tail
				toBeAdded.remove(0)
				result += p
			}
			(result.toList, remaining)
		}
		
		var remaining = cnfVars
		val result = mutable.ListBuffer[FixUnit]()
		while(remaining.size > 0) {
			val (eqClass, newRemaining) = separateEqClass(remaining.head, remaining.tail)
			val rangeUnit = eqClass.map(p => new RangeUnit(p._2, clause2GExpr(p._1))).reduceLeft(_ ++ _)
			val unit = rangeUnit.constraint match {
				case Eq(v:IdentifierRef, c:Expression) if rangeUnit.vars.size == 1 => new AssignmentUnit(rangeUnit.vars.head, c)
				case Eq(c:Expression, v:IdentifierRef) if rangeUnit.vars.size == 1 => new AssignmentUnit(rangeUnit.vars.head, c)
				case Not(v:IdentifierRef) => new AssignmentUnit(v.id, BoolLiteral(false))
				case v:IdentifierRef => new AssignmentUnit(v.id, BoolLiteral(true))
				case _ => rangeUnit
			}
			result += unit
			remaining = newRemaining
		}
		new DataFix(result)
	}
						
	

}