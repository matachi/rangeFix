package ca.uwaterloo.gsd.rangeFix
import collection._

// "allExpressions" should contain all constraints and all literals in configurations
class Expression2SMT(allExpressions:Iterable[Expression], types:Expression.Types) {

	private val StringSeparator = " "
	private val EnumTypePrefix = "__enum__"
	private val EnumIntPrefix = "__enum_int__"
	private val EnumStringPrefix = "__enum_str__"
	private val EnumToIntPrefix = "__enum_to_int__"
	private val EnumToStringPrefix = "__enum_to_str__"
	private val EnumFuncPara = "__x__"
	private val (allSetWords, allStrings, allEnumTypes, usedIdentifierTypes):(Map[String, Int], Map[String, Int], Map[EnumType, Int], Map[String, Type]) = {
		import org.kiama.rewriting.Rewriter._ 
		val setWords = mutable.Set[String]()
		val strings = mutable.Set[String]()
		val enumTypes = mutable.Set[EnumType]()
		val identifierTypes = mutable.Map[String, Type]()
		rewrite(everywhere(query{
			case SetLiteral(s) => 
				setWords ++= s
			case StringLiteral(s) =>
				strings += s
			case EnumLiteral(_, t) => 
				enumTypes += t
			case IdentifierRef(id) =>
				val t = types(id)
				if (t.isInstanceOf[EnumType]) enumTypes += t.asInstanceOf[EnumType]
				identifierTypes put (id, t)
		}))(allExpressions)
		
		var index = 0
		val resultSetWords = 
			(List(("0", 1)) ++
			(for (s <- (setWords - "0")) yield {
				index += 1
				(s, index)
			})).toMap

		index = 1
		val resultStrings = 
			(List(("", 0), ("0", 1)) ++
			(for (s <- strings) yield {
				index += 1
				(s, index)
			})).toMap
			
		// val x = new java.io.FileWriter("allStrings.txt")
		// for ((word, i) <- resultSetWords) x.write(word + ":" + i + "\n")
		// x.close
		
		
		index = 0
		val resultEnumTypes = 
			(for (e <- enumTypes) yield {
				index += 1
				(e, index - 1)
			}).toMap
		

		(resultSetWords, resultStrings, resultEnumTypes, identifierTypes)
	}
	
	type BitVector = Array[Boolean]
	def BVLength = allSetWords.size
	
	private def enum2ScalarType(e:EnumType) = SMTScalarType(EnumTypePrefix + allEnumTypes(e), e.items.map(enumItem2String(_, e)))
	
	private def enumItem2String(x:EnumItemLiteral, t:EnumType) = x match {
		case StringLiteral(s) => EnumStringPrefix + allEnumTypes(t) + "_" + s
		case IntLiteral(i) => EnumIntPrefix + allEnumTypes(t) + "_" + i
	}
	
	private def enumItem2ScalarLiteral(x:EnumItemLiteral, t:EnumType) = SMTScalarLiteral(enumItem2String(x, t))
	
	def SMTTypes():Map[String, SMTType] = 
		usedIdentifierTypes.mapValues(_ match {
			case NumberType => SMTIntType
			case StringType => SMTIntType
			case BoolType => SMTBoolType
			case SetType => SMTBVType(BVLength)
			case e:EnumType => enum2ScalarType(e)
		})
		
	def type2SMTTypeAndFunc(t:Type):(SMTType, Iterable[SMTFuncDefine]) = {
		t match {
			case NumberType => (SMTIntType, List())
			case StringType => (SMTIntType, List())
			case BoolType => (SMTBoolType, List())
			case SetType => (SMTBVType(BVLength), List())
			case e:EnumType => (enum2ScalarType(e), List(enum2IntFunc(e)))
		}		
	}
	def type2SMTType(t:Type):SMTType = {
		t match {
			case NumberType => SMTIntType
			case StringType => SMTIntType
			case BoolType => SMTBoolType
			case SetType => SMTBVType(BVLength)
			case e:EnumType => enum2ScalarType(e)
		}		
	}
	def type2SMTFunc(t:Type):Iterable[SMTFuncDefine] = {
		t match {
			case e:EnumType => List(enum2IntFunc(e))
			case _ => List()
		}		
	}
	
	def convertTypes(types:Map[String, Type]) = (types.mapValues(type2SMTTypeAndFunc(_)._1), types.values.toSet[Type].map(type2SMTTypeAndFunc(_)._2).flatten)
	
	// for defining the types later
	// def allTypes():Iterable[SMTType] = {
		// Set(SMTIntType, SMTBVType(BVLength), SMTBoolType) ++ 
			// usedIdentifierTypes.values.filter(_.isInstanceOf[EnumType]).map(t => enum2ScalarType(t.asInstanceOf[EnumType]))
	// }

	// the converstion functions converting enums to ints
	
	private def enum2IntFunc(t:EnumType) = {
		val index = allEnumTypes(t)
		assert(t.items.size > 1)
		def toInt(el:EnumItemLiteral):SMTExpression = el match {
			case IntLiteral(i) => SMTIntLiteral(i)
			case StringLiteral(s) => 
				try { 
					SMTIntLiteral(s.toInt)
				} catch {
					case _:NumberFormatException => SMTIntLiteral(0)
				}
		} 
		val body = t.items.tail.foldRight(toInt(t.items.head))((l, e) => SMTConditional(SMTVarRef(EnumFuncPara) === enumItem2ScalarLiteral(l, t), toInt(l), e))
		SMTFuncDefine(EnumToIntPrefix + index, List((EnumFuncPara, enum2ScalarType(t))), SMTIntType, body)
	}
	
	private def allIntFuncs() = {
		for((t, index) <- allEnumTypes) yield {
			assert(t.items.size > 1)
			def toInt(el:EnumItemLiteral):SMTExpression = el match {
				case IntLiteral(i) => SMTIntLiteral(i)
				case StringLiteral(s) => 
					try { 
						SMTIntLiteral(s.toInt)
					} catch {
						case _:NumberFormatException => SMTIntLiteral(0)
					}
			} 
			val body = t.items.tail.foldRight(toInt(t.items.head))((l, e) => SMTConditional(SMTVarRef(EnumFuncPara) === enumItem2ScalarLiteral(l, t), toInt(l), e))
			SMTFuncDefine(EnumToIntPrefix + index, List((EnumFuncPara, enum2ScalarType(t))), SMTIntType, body)
		}
	}
	
	def allFunctions():Iterable[SMTFuncDefine] = allIntFuncs // String functions are not implemented since we have not encountered them
	
	// private def string2BitVector(str:String):SMTBVLiteral = {
		// val ss = str.split(" ")
		// val result = new BitVector(BVLength)
		// for(s <- ss) {
			// result(allSetWords(s)) = true
		// }
		// SMTBVLiteral(result)
	// }
	
	private def string2Int(str:String):SMTIntLiteral = SMTIntLiteral(allStrings(str))
	
	private def set2BitVector(items:Set[String]):SMTBVLiteral = {
		val result = new BitVector(BVLength)
		for(s <- items) {
			result(allSetWords(s)) = true
		}
		SMTBVLiteral(result)
	}

	def convert(expr:Expression):SMTExpression = expr match {
		case StringLiteral(s) => string2Int(s)
		case SetLiteral(items) => set2BitVector(items)
		case IntLiteral(i) => SMTIntLiteral(i)
		case BoolLiteral(b) => SMTBoolLiteral(b)
		case RealLiteral(r) => throw new IllegalArgumentException("found real value")
		case EnumLiteral(v, t) => enumItem2ScalarLiteral(v, t)
		case IdentifierRef(id) => SMTVarRef(id)
		case Conditional(c, p, f) => SMTConditional(convert(c), convert(p), convert(f))
		case And(l, r) => SMTAnd(convert(l), convert(r))
		case Or(l, r) => SMTOr(convert(l), convert(r))
		case Implies(l, r) => SMTImplies(convert(l), convert(r))
		case Eq(l, r) => SMTEq(convert(l), convert(r))
		case NEq(l, r) => SMTNot(SMTEq(convert(l), convert(r)))
		case LessThan(l, r) => SMTLessThan(convert(l), convert(r))
		case LessThanOrEq(l, r) => SMTLessEqThan(convert(l), convert(r))
		case GreaterThan(l, r) => SMTGreaterThan(convert(l), convert(r))
		case GreaterThanOrEq(l, r) => SMTGreaterEqThan(convert(l), convert(r))
		case Plus(l, r) => SMTPlus(convert(l), convert(r))
		case Minus(l, r) => SMTMinus(convert(l), convert(r))
		case Times(l, r) => SMTTimes(convert(l), convert(r))
		case Div(l, r) => SMTDivide(convert(l), convert(r))
		case Mod(l, r) => SMTMod(convert(l), convert(r))
		case Dot(l, r) => SMTBOr(convert(l), convert(r))
		case Not(l) => SMTNot(convert(l))
		case IsSubstr(l, r) => 
			SMTBAnd(SMTBNot(convert(l)), convert(r)) === SMTBVLiteral(new BitVector(BVLength))
		case ToInt(e) => ExpressionHelper.getType(e, types) match {
			case StringType => throw new IllegalArgumentException("converting string to int")
			case SetType => throw new IllegalArgumentException("converting set to int")
			case NumberType => convert(e)
			case BoolType => SMTConditional(convert(e), SMTIntLiteral(1), SMTIntLiteral(0))
			case t:EnumType => SMTUserFuncCall(EnumToIntPrefix + allEnumTypes(t), convert(e))
		}
		case ToString(e) => throw new IllegalArgumentException("toString is not supported yet")
		case ToBool(e) => ExpressionHelper.getType(e, types) match {
			case SetType => SMTNot(convert(e) === set2BitVector(Set())) & SMTNot(convert(e) === set2BitVector(Set("0")))
			case StringType => SMTNot(convert(e) === string2Int("")) & SMTNot(convert(e) === string2Int("0"))
			case NumberType => SMTNot(convert(e) === 0)
			case BoolType => convert(e)
			case t:EnumType => SMTNot(convert(e) === enumItem2ScalarLiteral(IntLiteral(0), t))
		case x@_ => throw new IllegalArgumentException("unexpected expression:" + x)
		}
	}
}