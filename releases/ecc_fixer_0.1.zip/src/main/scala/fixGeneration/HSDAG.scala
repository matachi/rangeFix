package ca.uwaterloo.gsd.rangeFix
import scala.collection.mutable.Queue
import java.util.Date
import scala.collection.mutable.Stack

abstract class GraphBase[T, U] {
  case class Edge(source: Node, target: Node, h: U) {
    def toTuple = (source.conflicts, target.conflicts, h)
  }
  case class Node(value: T) {
    var conflicts = value
    var descendants: List[Edge] = Nil
    var ancestors: List[Edge] = Nil
  }
  var nodes: List[Node] = Nil
}

class HSDAG[T] extends GraphBase[List[T], T]{

  private def addArc(source: Node, target: Node, value: T): Edge = {
    val e = new Edge(source, target, value)
    source.descendants = e :: source.descendants
    target.ancestors = e :: target.ancestors
    e
  }

  private def addNode(value: List[T]) = {
    val n = new Node(value)
    nodes = n :: nodes
    n
  }

  private def getH(n: Node): List[T] = {
    var Hn: List[T] = Nil

    if (n.ancestors.isEmpty) // the source node has no ancestors
      Hn = Nil
    else { // the source node has ancestors, we have to recursively compute H(n)
      val ancestor  = n.ancestors.head  // we take only the first element because every H(n) of ancestors
                                        // will be the same (see 1. Reusing Nodes: (a))
      Hn = ancestor.h :: getH(ancestor.source)
    }
    return Hn
  }
  
  private def reuseNode(Hm: List[T]): Node = {
    var isSubset = true
    for (n <- nodes) {
      for (m <- Hm) {
        if(!getH(n).contains(m)){
          isSubset = false
        }
      }
      if (isSubset)
        return n
      else
        isSubset = true
    }
    return null
  }
  
  private def dropIndex[T](xs: List[T], n: Int): List[T] = {
    val (l1, l2) = xs splitAt n
    l1 ::: (l2 drop 1)
  }


  private def getSupersetNodes(conflict: List[T]): List[Node] = {
    var supersetNodes: List[Node] = Nil
    var isSuperset = true

    for (n <- nodes) {
      if(n.conflicts.length>conflict.length) {
        for(c <- conflict) {
          if(!n.conflicts.contains(c))
            isSuperset = false

        }
      } else {
        isSuperset = false
      }

      if(isSuperset) {
        supersetNodes = n :: supersetNodes
      }
      isSuperset = true
    }
    return supersetNodes
  }

  private def cutBranch(edge: Edge) : List[Node] = {
    var deletedNodes: List[Node] = Nil
    val parent = edge.source
    val nodeToPrune = edge.target
    // remove the edge from the parent
    var i = parent.descendants.indexOf(edge)
    parent.descendants = dropIndex[Edge](parent.descendants,i)
    // cut the branch
    if(nodeToPrune.ancestors.length==1) {
      // cut the children
      for(dn <- nodeToPrune.descendants) {
        deletedNodes = cutBranch(dn) ++ deletedNodes
      }

      // remove the node from the list of nodes
      i = nodes.indexOf(nodeToPrune)
      nodes = dropIndex[Node](nodes,i)
      deletedNodes = nodeToPrune :: deletedNodes
    }
    return deletedNodes
  }
  
  private def pruneDescendants (node: Node, conflicts: List[T] ) : List[Node] = {
    var deletedNodes: List[Node] = Nil
    for(c <- node.conflicts) {
      if(!conflicts.contains(c)) {
        for(d <- node.descendants) {
          if(d.h==c) {
            deletedNodes = cutBranch(d) ++ Nil
          }
        }
      }
    }
    return deletedNodes
  }
  
  private def closingNode(Hn: List[T]): Boolean = {
    var isSuperset = true

    for (m <- nodes) {
      var Hm = getH(m)
      if(Hm.length<Hn.length && m.conflicts.isEmpty) {
        for(h <- Hm) {
          if(!Hn.contains(h))
            isSuperset = false
        }
      } else {
        isSuperset = false
      }

      if(isSuperset) {
        return true
      }
      isSuperset = true
    }
    return false

  }


  private def relabel(node: Node, label: List[T]) = {
    node.conflicts = label
  }
  
  private def removeSubset[T](subset: List[T], list: List[T]) : List[T] = {
    var reducedList: List[T] = list
    for(s <- subset) {
      var i = reducedList.indexOf(s)
      reducedList = dropIndex[T](reducedList,i)
    }
    return reducedList
  }
  
  def getDiagnoses(getCore : Traversable[T] => Option[List[T]]): List[List[T]] = {
    var diagnoses: List[List[T]] = Nil
    var stack = new Stack[Node]

    val root = computeHSDAG(getCore)

    if(!root.isEmpty)
      stack.push(root.get)

    while(!stack.isEmpty) {
      var node = stack.pop

      if(node.conflicts.isEmpty) {
        var Hn = getH(node)
        if (!diagnoses.contains(Hn))
          diagnoses = getH(node) :: diagnoses
      } else {
        for (e <- node.descendants) {
          stack.push(e.target)
        }
      }
     }

    return diagnoses
  } 
  
  // None means unsat
  private def computeHSDAG(getCore : List[T] => Option[List[T]]): Option[Node] = {
    var mus  = getCore(List()) // minimal unsat subset (QuickXplain)
	var conflicts = if (mus!=None) {
	  if (mus.get.isEmpty) return None
	  mus.get
	} else {
	  Nil
	}
	// Step 1: create root
	val root = addNode(conflicts)
	// Step 2: process nodes in BFS
	val queue = new Queue[Node]
	queue += root
	while (!queue.isEmpty) {
		var node = queue.dequeue

		if(!node.conflicts.isEmpty) {  // we only look into nodes that are not marked with V

		  for (c <- node.conflicts) {
			var Hm = c :: getH(node)
			if(!closingNode(Hm)) {  // 2. Closing. Here closing is implemented by not exploring the
									// descendants, i.e. not putting it in the queue and expanding the node.
			  var reusedNode = reuseNode(Hm)
			  if(reusedNode!=null) { // 1. Reusing Nodes
				addArc(node,reusedNode,c) // Reuse node
			  } else {
				mus  = getCore(Hm)
				if (mus!=None) {
				  if (mus.get.isEmpty) return None
				  conflicts = mus.get
				} else {
				  conflicts = Nil
				}
				if(!conflicts.isEmpty) {          // 3. Pruning
				  var supersetNodes = getSupersetNodes(conflicts)
				  if(!supersetNodes.isEmpty) {
					while(!supersetNodes.isEmpty) {
					  // remove the first element from the list
					  var s = supersetNodes.head
					  var i = supersetNodes.indexOf(s)
					  supersetNodes = dropIndex[Node](supersetNodes,i)
					  // cut branches that that are not in conflict
					  var removedNodes = pruneDescendants(s,conflicts)
					  // relabel s with conflict
					  relabel(s,conflicts)
					  // remove the nodes from the list that have been pruned
					  supersetNodes = removeSubset[Node](removedNodes,supersetNodes)
					}
				  }
				}
				var cnode = addNode(conflicts)
				addArc(node,cnode,c)
				queue += cnode
			  }
			}
		  }
		}
	}
	val end = (new Date).getTime()
	return Some(root)
  }
}