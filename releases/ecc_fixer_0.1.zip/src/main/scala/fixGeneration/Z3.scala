package ca.uwaterloo.gsd.rangeFix
import java.io.OutputStreamWriter
import java.lang.Runtime
import java.io.InputStreamReader
import java.io.BufferedReader
import java.io.BufferedWriter
import java.io.Writer
import java.io.FileWriter

class TraceWriter(w:Writer) {
	def write(content:String) = {
		val f = new FileWriter("temp.txt", true)
		f.write(content)
		f.close
		w.write(content)
	}
	
	def flush() = w.flush()
	
}

class Z3 {
  val fixedParams = Array(CompilationOptions.Z3_PATH, "/si", "/smt2")
  val parameters = if (CompilationOptions.THREAD_NUMBER == 1) fixedParams else fixedParams ++ List("PAR_NUM_THREADS=" + CompilationOptions.THREAD_NUMBER)
  val p = Runtime.getRuntime().exec(parameters)
  val writer = new BufferedWriter(new OutputStreamWriter(p.getOutputStream()))
  val reader = new BufferedReader(new InputStreamReader(p.getInputStream()))

  def declareVariables(vars: Iterable[(String, SMTType)]) {
	assert(reader.ready() == false, reader.readLine)
    for (v <- vars) {
		writer.write("(declare-const ")
		writer.write(v._1 + " "
			+ v._2.toString);
		writer.write(")\n")
    }
	// writer.flush()
	assert(reader.ready() == false)
  }
  
  
  // assuming no string
  def assertConstraint(constraint: SMTExpression) {
   	assertConstraint(constraint.toString)
  }

  def assertConstraint(constraint: String) {
	assert(reader.ready() == false, reader.readLine)
	// println("### asserting ### " + constraint)
    writer.write("(assert " + constraint + ")\n")
	// writer.flush()
	assert(reader.ready() == false, constraint + " => " + reader.readLine())
	
  }
  
  def assertNamedConstraint(constraint:SMTExpression, name:String) {
	assertNamedConstraint(constraint.toString, name)
  }

  
  def assertNamedConstraint(constraint:String, name:String) {
	assert(reader.ready() == false, reader.readLine)
	writer.write("(assert (! " + constraint + " :named " + name + "))\n")
	// writer.flush()
	assert(reader.ready() == false)
  }
  
  def declareTypes(types: Iterable[SMTType]) {
	assert(reader.ready() == false, reader.readLine)
	val texts = types.map(_.toDeclaration).filter(_ != "")
	if (texts.size == 0) return
	writer.write("(declare-datatypes () (" + texts.reduceLeft(_ + _) + "))\n")
	// writer.flush()
	assert(reader.ready() == false)
  }
  
  def declareFunc(func: SMTFuncDefine) {
	assert(reader.ready() == false, reader.readLine)
	writer.write(func.toDefString + "\n")
	// writer.flush()
	assert(reader.ready() == false, reader.readLine)
  
  }
  

  def push() {
	assert(reader.ready() == false, reader.readLine)
	writer.write("(push)\n")
	// writer.flush()
	assert(reader.ready() == false)
  }

  def pop() {
	assert(reader.ready() == false, reader.readLine)
	writer.write("(pop)\n")
	// writer.flush()
	assert(reader.ready() == false, reader.readLine)
  }
  
  def checkSat(): Boolean = {
	assert(reader.ready() == false, reader.readLine)
    writer.write("(check-sat)\n")
	writer.flush()
    val line = reader.readLine();
	assert(reader.ready() == false, reader.readLine)
    if (line == "sat") true 
	else {
		assert( line == "unsat", line )
		false
	}
  }
  
  def enableUnsatCore() {
	assert(reader.ready() == false, reader.readLine)
	writer.write("(set-option :produce-unsat-cores true)\n")
	// writer.flush()
	assert(reader.ready() == false)
  }
  
  val exprNamePrefix = "__ex__"
  def getUnsatCore(vars: Iterable[String]): Option[Traversable[String]] = 
  {
	assert(reader.ready() == false, reader.readLine)
	push()
	try {
		for (v <- vars)
			assertNamedConstraint(v, exprNamePrefix + v)
		if (checkSat) {
			None
		}
		else {
			val result = getUnsatCore()
			result.map(_.map(name => {assert(name.size > exprNamePrefix.size); name.substring(exprNamePrefix.size)}))
		}
	}
	finally {
		pop()
		assert(reader.ready() == false, reader.readLine)
	}
  }

  // None means sat
  def getUnsatCore(): Option[Traversable[String]] = {
	assert(reader.ready() == false, reader.readLine)
	// println("### get-core ### " + varstr)
    writer.write("(get-unsat-core)\n")
	writer.flush()
    val line = reader.readLine()
	assert(reader.ready() == false, reader.readLine)
	val pattern = "(error \"line \\d+ column \\d+: unsat core is not available\")".r
	// println("### result ### " + line)
	if (pattern.findFirstIn(line) == line) return None
	assert(line.length() >= 2, line)
	assert(!line.startsWith("(error "), line)
	val trimmedLine = line.substring(1, line.length - 1)
	(if (trimmedLine.size == 0) Some(List()) else Some(trimmedLine.split(" ")))
  }	 


  def exit() {
    writer.write("(exit)\n")
	try{
		writer.flush()
	}
	catch{
		case _ => //may have been closed
	}
    p.waitFor()
  }
}